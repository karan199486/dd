package sl;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import pojo.Employee;
import dao.EmployeeDao;
import dao.EmployeeDaoImpl;
import dao.MyConnection;

public class EmployeeService {
	Connection con = MyConnection.connectionobj;
	EmployeeDao edao = new EmployeeDaoImpl();
	
	public boolean addEmployee(Employee e) {
		
		String date = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
		e.setJoiningdate(date);
		return edao.addEmployee(e);
		
	}


	public boolean modifyEmployee(String query) {
		return false;
	}


	public void displayAll() {
		List<Employee> list= edao.displayAll();
		
		for(Employee e: list)
		{
			Double bsal = e.getBsalary();
			Double tsal = bsal + .2*bsal + .4*bsal;
			tsal += .1*tsal;
			
			System.out.format("%s\t%s %s\t%s\t%s\t%s\t%f",e.getEmpno(),e.getfName(),e.getlName(),
					e.ep.getDob(), e.getDesignation(), e.getDept(), tsal);
		}
	}
}
