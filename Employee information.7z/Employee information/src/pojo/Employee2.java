package pojo;

public class Employee2 {
	private String empno, dob, eduq, add1, add2, city;
	private Integer pin, phone;
	public Employee2(String dob, String eduq, String add1, String add2,
			String city, Integer pin, Integer phone) {
		super();
		this.dob = dob;
		this.eduq = eduq;
		this.add1 = add1;
		this.add2 = add2;
		this.city = city;
		this.pin = pin;
		this.phone = phone;
	}
	public String getEmpno() {
		return empno;
	}
	public void setEmpno(String empno) {
		this.empno = empno;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEduq() {
		return eduq;
	}
	public void setEduq(String eduq) {
		this.eduq = eduq;
	}
	public String getAdd1() {
		return add1;
	}
	public void setAdd1(String add1) {
		this.add1 = add1;
	}
	public String getAdd2() {
		return add2;
	}
	public void setAdd2(String add2) {
		this.add2 = add2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getPin() {
		return pin;
	}
	public void setPin(Integer pin) {
		this.pin = pin;
	}
	public Integer getPhone() {
		return phone;
	}
	public void setPhone(Integer phone) {
		this.phone = phone;
	}
}
