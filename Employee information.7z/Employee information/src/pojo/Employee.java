package pojo;


public class Employee
{
	
	private String empno, fName, lName, dept, designation, joiningdate;
	public Employee_personal ep;
	private Double bsalary;
	public Employee(String empno, String fName, String lName, String dept,
			String designation, String joiningdate, Employee_personal ep,
			Double bsalary) {
		super();
		this.empno = empno;
		this.fName = fName;
		this.lName = lName;
		this.dept = dept;
		this.designation = designation;
		this.joiningdate = joiningdate;
		this.ep = ep;
		this.bsalary = bsalary;
	}
	public Employee(String fName, String lName, String dept,
			String designation, String joiningdate, Double bsalary) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.dept = dept;
		this.designation = designation;
		this.joiningdate = joiningdate;
		this.bsalary = bsalary;
		
	}
	public String getEmpno() {
		return empno;
	}
	public void setEmpno(String empno) {
		this.empno = empno;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getJoiningdate() {
		return joiningdate;
	}
	public void setJoiningdate(String joiningdate) {
		this.joiningdate = joiningdate;
	}
	public Double getBsalary() {
		return bsalary;
	}
	public void setBsalary(Double bsalary) {
		this.bsalary = bsalary;
	}
	
	
	
	public class Employee_personal
	{
		private String empno, dob, eduq, add1, add2, city;
		private Integer pin, phone;
		public Employee_personal(String dob, String eduq, String add1, String add2,
				String city, Integer pin, Integer phone) {
			super();
			this.dob = dob;
			this.eduq = eduq;
			this.add1 = add1;
			this.add2 = add2;
			this.city = city;
			this.pin = pin;
			this.phone = phone;
		}
		public String getEmpno() {
			return empno;
		}
		public void setEmpno(String empno) {
			this.empno = empno;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getEduq() {
			return eduq;
		}
		public void setEduq(String eduq) {
			this.eduq = eduq;
		}
		public String getAdd1() {
			return add1;
		}
		public void setAdd1(String add1) {
			this.add1 = add1;
		}
		public String getAdd2() {
			return add2;
		}
		public void setAdd2(String add2) {
			this.add2 = add2;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public Integer getPin() {
			return pin;
		}
		public void setPin(Integer pin) {
			this.pin = pin;
		}
		public Integer getPhone() {
			return phone;
		}
		public void setPhone(Integer phone) {
			this.phone = phone;
		}
	}
	
}
