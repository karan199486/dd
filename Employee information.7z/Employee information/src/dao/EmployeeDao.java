package dao;
import java.util.List;

import pojo.Employee;

public interface EmployeeDao {
	
	public boolean addEmployee(Employee e1);
	public boolean modifyEmployee(String query);
	public List<Employee> displayAll();
}
