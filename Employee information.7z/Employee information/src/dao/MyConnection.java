package dao;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class MyConnection {
	
	public static Connection connectionobj;
	
	static{
		 try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connectionobj = DriverManager.getConnection("jdbc:mysql://localhost:3306/karan","root","root");
			System.out.println("Connected!");
			
			//connectionobj.setAutoCommit(false);
			//System.out.println("set autocommit false");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("cannot load driver");
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("cannot create conn obj");
			e.printStackTrace();
		}
	}
	
}
