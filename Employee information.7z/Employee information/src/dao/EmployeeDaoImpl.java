package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	Connection con = MyConnection.connectionobj;
	@Override
	public boolean addEmployee(Employee e) {
		try {
			PreparedStatement ps = con.prepareStatement("insert into employee_table values(?,?,?,?,?,?,?);");
			ps.setInt(1, 0);
			ps.setString(2, e.getfName());
			ps.setString(3, e.getlName());
			ps.setString(4, e.getJoiningdate());
			ps.setString(5, e.getDesignation());
			ps.setString(6, e.getDept());
			ps.setDouble(7, e.getBsalary());
			int e1_rows = ps.executeUpdate();
			System.out.println("added +"+e1_rows+"rows in employee_table");
			
			
			
			ps = con.prepareStatement("insert into employee_personal_info_table values(?,?,?,?,?,?,?,?);");
			ps.setInt(1, 0);
			ps.setString(2, e.ep.getDob());
			ps.setString(3, e.ep.getEduq());
			ps.setString(4,e.ep.getAdd1());
			ps.setString(5,e.ep.getAdd2());
			ps.setString(6, e.ep.getCity());
			ps.setInt(7,e.ep.getPin());
			ps.setInt(8, e.ep.getPhone());
			int e2_rows = ps.executeUpdate();
			System.out.println("added +"+e1_rows+"rows in employee_table");
			//con.commit();
			System.out.println("commited!");
			return true;
			
		} catch (SQLException ex) {
			
			ex.printStackTrace();
			
		}
		
		return false;
	}

	@Override
	public boolean modifyEmployee(String query) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Employee> displayAll() {
		try {
//			PreparedStatement ps =con.prepareStatement("select * from employee_table");
//			ResultSet rs1 = ps.executeQuery();
//			ps =con.prepareStatement("select * from employee_personal_info_table");
//			ResultSet rs2 = ps.executeQuery();
			
			Statement ps = con.createStatement();
			ResultSet rs1 = ps.executeQuery("select * from employee_table");
			ps = con.createStatement();
			ResultSet rs2 = ps.executeQuery("select * from employee_personal_info_table");
			List<Employee> list1 = new ArrayList<Employee>();
			//List<Employee.Employee_personal> list2 = new ArrayList<Employee.Employee_personal>();
			
			while(rs1.next() && rs2.next()){
				Employee e = new Employee(String.valueOf(rs1.getInt(1)),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getString(6),null,rs1.getDouble(7));
				e.ep = e.new Employee_personal(""+rs2.getInt(1), rs2.getString(2),  rs2.getString(3), 
								rs2.getString(4), (String)rs2.getObject(5), rs2.getInt(6), rs2.getInt(7));
			}
			
			return list1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	
}
