package pl;
import java.util.*;

import pojo.Employee;
import sl.EmployeeService;

public class Main {
	static EmployeeService es = new EmployeeService();
	
	public static void main(String[] args)
	{
		es.displayAll();
		//add();
	}
	
	public static void add()
	{

		Scanner sc = new Scanner(System.in);
		
		System.out.println("fname:");
		String fname = sc.nextLine();
		System.out.println("lname :");
		String lname = sc.nextLine();
		System.out.println("dob:");
		String dob = sc.nextLine(); 
		System.out.println("dept:");
		String dept = sc.nextLine();
		System.out.println("designation:");
		String designation = sc.nextLine();
		System.out.println("sal:");
		Double bsalary = Double.parseDouble(sc.nextLine());
		System.out.println("eduq:");
		String eduq = sc.nextLine();
		System.out.println("address1:");
		String add1 = sc.nextLine();
		System.out.println("address2:");
		String add2 = sc.nextLine();
		System.out.println("city:");
		String city = sc.nextLine();
		System.out.println("pin:");
		Integer pin = Integer.parseInt(sc.nextLine());
		System.out.println("phone:");
		Integer phone = Integer.parseInt(sc.nextLine());
		
		
		Employee e1 = new Employee(fname, lname, dept, designation, null, bsalary);
		e1.ep = e1.new Employee_personal(dob, eduq, add1, add2, city, pin, phone);
		
		es.addEmployee(e1);
	}

}
